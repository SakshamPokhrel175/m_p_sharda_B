package com.mp.entity;


public enum Role {
ADMIN,
TEACHER,
STUDENT,
GENERAL_USER
}